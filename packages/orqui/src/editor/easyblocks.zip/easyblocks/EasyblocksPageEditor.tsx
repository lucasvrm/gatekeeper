// ============================================================================
// EasyblocksPageEditor — Drop-in replacement for PageEditor
//
// Uses the real EasyblocksEditor from @easyblocks/editor.
// Same public interface as page-editor/PageEditor.tsx.
//
// The EasyblocksEditor does NOT take a documentId — it manages document
// lifecycle internally via the Backend + URL hash. Our OrquiBackend
// bridges this to layout.pages.
// ============================================================================

import React, { useState, useCallback, useMemo, useEffect, Component, type ErrorInfo, type ReactNode } from "react";
import { EasyblocksEditor } from "@easyblocks/editor";
import type { PageDef, NodeDef } from "../page-editor/nodeDefaults";
import type { VariablesSection } from "../page-editor/variableSchema";
import { buildOrquiEasyblocksConfig } from "./config";
import { generateTokenCSSVariables } from "./bridge/tokens";
import { ORQUI_COMPONENTS } from "./components";
import { ORQUI_WIDGETS } from "./widgets/TemplatePickerWidget";

// ============================================================================
// Root component for new documents — OrquiStack acts as page root
// ============================================================================

const ROOT_COMPONENT_ID = "OrquiStack";

// ============================================================================
// Error Boundary — catches canvas/editor crashes without killing Orqui
// ============================================================================

interface ErrorBoundaryProps {
  onReset?: () => void;
  children: ReactNode;
}

interface ErrorBoundaryState {
  hasError: boolean;
  error: Error | null;
}

class EasyblocksErrorBoundary extends Component<ErrorBoundaryProps, ErrorBoundaryState> {
  constructor(props: ErrorBoundaryProps) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error: Error): ErrorBoundaryState {
    return { hasError: true, error };
  }

  componentDidCatch(error: Error, info: ErrorInfo) {
    console.error("[EasyblocksEditor] Canvas crash captured:", error, info.componentStack);
  }

  handleRetry = () => {
    this.setState({ hasError: false, error: null });
    this.props.onReset?.();
  };

  render() {
    if (this.state.hasError) {
      return (
        <div style={{
          display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center",
          height: "100%", width: "100%", gap: 16, padding: 32,
          background: "#0e0e11", color: "#e4e4e7",
        }}>
          <div style={{ fontSize: 40 }}>⚠️</div>
          <div style={{ fontSize: 16, fontWeight: 600 }}>O editor encontrou um erro</div>
          <div style={{
            fontSize: 12, color: "#8b8b96", maxWidth: 480, textAlign: "center", lineHeight: 1.5,
          }}>
            {this.state.error?.message || "Erro desconhecido no canvas do Easyblocks."}
          </div>
          <div style={{
            fontSize: 11, color: "#5b5b66", fontFamily: "'JetBrains Mono', monospace",
            maxWidth: 560, maxHeight: 120, overflow: "auto", padding: 12,
            background: "#141417", borderRadius: 6, border: "1px solid #2a2a33",
            whiteSpace: "pre-wrap", wordBreak: "break-all",
          }}>
            {this.state.error?.stack?.split("\n").slice(0, 6).join("\n") || "No stack trace"}
          </div>
          <div style={{ display: "flex", gap: 12, marginTop: 8 }}>
            <button
              onClick={this.handleRetry}
              style={{
                padding: "8px 20px", borderRadius: 6, border: "none",
                background: "#6d9cff", color: "#fff", fontSize: 13,
                fontWeight: 600, cursor: "pointer",
              }}
            >
              Tentar novamente
            </button>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}

// ============================================================================
// Public Interface (matches PageEditor exactly)
// ============================================================================

interface EasyblocksPageEditorProps {
  pages: Record<string, PageDef>;
  onPagesChange: (pages: Record<string, PageDef>) => void;
  tokens?: Record<string, any>;
  variables?: VariablesSection;
  onVariablesChange?: (v: VariablesSection) => void;
  externalVariables?: VariablesSection;
}

// ============================================================================
// Component
// ============================================================================

export function EasyblocksPageEditor({
  pages,
  onPagesChange,
  tokens = {},
  variables,
  onVariablesChange,
  externalVariables,
}: EasyblocksPageEditorProps) {
  const [ready, setReady] = useState(false);
  const [resetKey, setResetKey] = useState(0);

  // ---- Inject URL params that EasyblocksEditor reads via window.location.search ----
  //
  // Easyblocks reads these from window.location.search at init:
  //   ?document={id}       → load existing document
  //   ?rootComponent={id}  → create new document with this root
  //   ?readOnly             → presence of this param (any value) may trigger read-only
  //
  // Strategy:
  //   - If pages exist: inject ?document={firstPageId} to load existing content
  //   - If no pages: inject ?rootComponent=OrquiStack to create fresh
  //   - Always DELETE ?readOnly to ensure edit mode
  // ============================================================================

  const pageIds = useMemo(() => Object.keys(pages), [pages]);

  useEffect(() => {
    const url = new URL(window.location.href);
    const params = url.searchParams;

    // Always remove readOnly — its presence (any value) can lock the editor
    params.delete("readOnly");

    // Decide: load existing document vs create new
    if (!params.has("document") && !params.has("rootComponent") && !params.has("rootTemplate")) {
      if (pageIds.length > 0) {
        // Load the first existing page
        params.set("document", pageIds[0]);
      } else {
        // No pages — create a fresh document
        params.set("rootComponent", ROOT_COMPONENT_ID);
      }
    }

    window.history.replaceState({}, "", url.toString());
    setReady(true);

    // Cleanup: remove injected params when unmounting
    return () => {
      const cleanUrl = new URL(window.location.href);
      cleanUrl.searchParams.delete("rootComponent");
      cleanUrl.searchParams.delete("document");
      cleanUrl.searchParams.delete("rootTemplate");
      cleanUrl.searchParams.delete("readOnly");
      window.history.replaceState({}, "", cleanUrl.toString());
    };
  }, []);

  // ---- Build Easyblocks config ----
  const handlePageChange = useCallback((pageId: string, page: PageDef) => {
    onPagesChange({ ...pages, [pageId]: page });
  }, [pages, onPagesChange]);

  const config = useMemo(
    () => buildOrquiEasyblocksConfig({
      tokens,
      pages,
      onPageChange: handlePageChange,
    }),
    [tokens, pages, handlePageChange]
  );

  // ---- CSS variables for Orqui tokens ----
  const tokenCSS = useMemo(() => generateTokenCSSVariables(tokens), [tokens]);

  // ---- Error boundary reset handler ----
  const handleErrorReset = useCallback(() => {
    setResetKey(k => k + 1);
  }, []);

  // ---- Wait for URL params before rendering editor ----
  if (!ready) return null;

  // ════════════════════════════════════════════════════════════════════════════
  // RENDER
  // ════════════════════════════════════════════════════════════════════════════
  return (
    <div style={{ height: "100%", width: "100%", position: "relative" }}>
      {/* Inject Orqui token CSS variables into the page */}
      <style>{tokenCSS}</style>

      {/* Error Boundary wraps the editor to catch canvas crashes */}
      <EasyblocksErrorBoundary onReset={handleErrorReset}>
        {/* Real Easyblocks Editor — key forces remount on error recovery */}
        <EasyblocksEditor
          key={resetKey}
          config={config}
          components={ORQUI_COMPONENTS}
          widgets={ORQUI_WIDGETS}
        />
      </EasyblocksErrorBoundary>
    </div>
  );
}
