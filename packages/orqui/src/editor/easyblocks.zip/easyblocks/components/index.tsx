// ============================================================================
// Orqui React Components for Easyblocks Canvas
//
// Each NoCode Component Definition needs a corresponding React component.
//
// ⚠️ CRITICAL: Easyblocks' buildBoxes() passes styled slots (Root, Label, etc.)
// as ReactElement instances — NOT as ComponentType. The correct usage is:
//
//   React.createElement(Root.type, Root.props, children)
//     or via helper: S(Root, children)
//
// NEVER use <Root>{children}</Root> — that treats Root as a component class/fn.
//
// Evidence: every builtin EB component uses Root.type / Root.props:
//   @easyblocks/core/dist/es/compiler/builtins/_richText/_richText.client.js
//   → return React.createElement(Root.type, Root.props, Elements.map(...))
//
// These components are used ONLY in the Easyblocks editor canvas.
// The production runtime continues to use NodeRenderer from runtime/.
// ============================================================================

import React, { type ReactNode, type ReactElement, type ComponentType } from "react";

// ============================================================================
// Core helper — renders a styled ReactElement with children
// ============================================================================

/**
 * S(element, ...children) — "Styled render"
 *
 * Easyblocks styled slots are ReactElements. To render them with our own
 * children we must call createElement with their type and props.
 *
 * Handles edge cases:
 * - element is null/undefined → returns children wrapped in fragment
 * - element is a ComponentType (defensive) → renders as JSX component
 */
function S(el: ReactElement | null | undefined, ...children: ReactNode[]): ReactElement {
  if (!el) {
    return React.createElement(React.Fragment, null, ...children);
  }
  // Defensive: if somehow passed a component type instead of element
  if (typeof el === "function" || (typeof el === "object" && !("type" in el))) {
    const Comp = el as unknown as ComponentType<any>;
    return React.createElement(Comp, null, ...children);
  }
  return React.createElement(el.type, el.props, ...children);
}

/** S0(element) — render a styled element with no children (self-closing) */
function S0(el: ReactElement | null | undefined): ReactElement {
  if (!el) return React.createElement(React.Fragment);
  if (typeof el === "function") {
    return React.createElement(el as unknown as ComponentType<any>);
  }
  return React.createElement(el.type, el.props);
}

// ============================================================================
// Type alias for styled slot props
// ============================================================================

/** A styled slot from Easyblocks — always a ReactElement at runtime */
type Slot = ReactElement;

// ============================================================================
// Layout Components
// ============================================================================

export function OrquiStack({ Root, Children }: { Root: Slot; Children: ReactNode }) {
  return S(Root, Children);
}

export function OrquiRow({ Root, Children }: { Root: Slot; Children: ReactNode }) {
  return S(Root, Children);
}

export function OrquiGrid({ Root, Children }: { Root: Slot; Children: ReactNode }) {
  return S(Root, Children);
}

export function OrquiContainer({ Root, Children }: { Root: Slot; Children: ReactNode }) {
  return S(Root, Children);
}

// ============================================================================
// Content Components
// ============================================================================

export function OrquiHeading({ Root, content, as: Tag = "h2" }: {
  Root: Slot; content: string; as?: string;
}) {
  return S(
    Root,
    React.createElement(Tag, {
      style: { margin: 0, fontSize: "inherit", fontWeight: "inherit" },
    }, content),
  );
}

export function OrquiText({ Root, content }: { Root: Slot; content: string }) {
  return S(Root, React.createElement("p", { style: { margin: 0 } }, content));
}

export function OrquiButton({ Root, label, icon }: {
  Root: Slot; label: string; icon?: string;
}) {
  return S(
    Root,
    icon ? React.createElement("span", { style: { fontSize: "1em" } }, icon) : null,
    React.createElement("span", null, label),
  );
}

export function OrquiBadge({ Root, content }: { Root: Slot; content: string }) {
  return S(Root, content);
}

export function OrquiIcon({ Root, name, size }: {
  Root: Slot; name: string; size: string;
}) {
  return S(
    Root,
    React.createElement("span", {
      style: {
        fontSize: `${Math.max(parseInt(size) * 0.5, 10)}px`,
        opacity: 0.5,
        fontFamily: "'JetBrains Mono', monospace",
      },
    }, name),
  );
}

export function OrquiImage({ Root, src, alt, size, rounded }: {
  Root: Slot; src: string; alt: string; size: string; rounded: boolean;
}) {
  if (!src) {
    return S(
      Root,
      React.createElement("div", {
        style: {
          width: `${size}px`, height: `${size}px`,
          background: "#1c1c21", border: "1px dashed #3a3a45",
          borderRadius: rounded ? "9999px" : "4px",
          display: "flex", alignItems: "center", justifyContent: "center",
          fontSize: 10, color: "#5b5b66",
        },
      }, "IMG"),
    );
  }
  return S(
    Root,
    React.createElement("img", {
      src, alt,
      style: {
        width: `${size}px`, height: `${size}px`,
        objectFit: "cover" as const,
        borderRadius: rounded ? "9999px" : "4px",
      },
    }),
  );
}

export function OrquiDivider({ Root }: { Root: Slot }) {
  return S0(Root);
}

export function OrquiSpacer({ Root }: { Root: Slot }) {
  return S0(Root);
}

// ============================================================================
// Data Components
// ============================================================================

export function OrquiStatCard({ Root, Label, Value, IconWrapper, label, value, icon }: {
  Root: Slot; Label: Slot; Value: Slot; IconWrapper: Slot;
  label: string; value: string; icon: string;
}) {
  return S(
    Root,
    React.createElement("div", {
      style: { display: "flex", justifyContent: "space-between", alignItems: "flex-start" },
    },
      React.createElement("div", null,
        S(Label, label),
        S(Value, value),
      ),
      S(IconWrapper, React.createElement("span", { style: { fontSize: 16 } }, icon)),
    ),
  );
}

export function OrquiCard({ Root, Header, Body, title, Children }: {
  Root: Slot; Header: Slot; Body: Slot;
  title: string; Children: ReactNode;
}) {
  return S(
    Root,
    title ? S(Header, title) : null,
    S(Body, Children),
  );
}

export function OrquiTable({ Root, HeaderCell, Cell, dataSource, columnsJson }: {
  Root: Slot; HeaderCell: Slot; Cell: Slot;
  dataSource: string; columnsJson: string;
}) {
  let columns: Array<{ key: string; label: string; width?: string }> = [];
  try { columns = JSON.parse(columnsJson); } catch { /* ignore */ }

  // For multi-instance styled slots (HeaderCell, Cell) we need to clone
  // per-cell since each is a single ReactElement. We reconstruct with
  // createElement for each cell.
  const headerCells = columns.map(col =>
    React.createElement(
      HeaderCell.type, { ...HeaderCell.props, key: col.key, style: { ...HeaderCell.props?.style, width: col.width } },
      col.label,
    ),
  );

  const bodyRows = [1, 2, 3].map(row =>
    React.createElement("tr", { key: row },
      columns.map(col =>
        React.createElement(
          Cell.type, { ...Cell.props, key: `${row}-${col.key}` },
          React.createElement("span", { style: { opacity: 0.4 } }, `{${dataSource}[${row}].${col.key}}`),
        ),
      ),
    ),
  );

  return S(
    Root,
    React.createElement("table", { style: { width: "100%", borderCollapse: "collapse" as const } },
      React.createElement("thead", null, React.createElement("tr", null, headerCells)),
      React.createElement("tbody", null, bodyRows),
    ),
  );
}

export function OrquiList({ Root, Item, dataSource, maxItems }: {
  Root: Slot; Item: Slot;
  dataSource: string; maxItems: string;
}) {
  const count = Math.min(parseInt(maxItems) || 3, 5);
  const items = Array.from({ length: count }, (_, i) =>
    React.createElement(
      Item.type, { ...Item.props, key: i },
      React.createElement("span", { style: { opacity: 0.4 } }, `{${dataSource}[${i}]}`),
    ),
  );
  return S(Root, ...items);
}

export function OrquiKeyValue({ Root, Pair, Label, Value, layout, itemsJson }: {
  Root: Slot; Pair: Slot; Label: Slot; Value: Slot;
  layout: string; itemsJson: string;
}) {
  let items: Array<{ label: string; value: string }> = [];
  try { items = JSON.parse(itemsJson); } catch { /* ignore */ }

  const pairs = items.map((item, i) =>
    React.createElement(Pair.type, { ...Pair.props, key: i },
      React.createElement(Label.type, Label.props, item.label),
      React.createElement(Value.type, Value.props, item.value),
    ),
  );
  return S(Root, ...pairs);
}

// ============================================================================
// Navigation, Input & Special Components
// ============================================================================

export function OrquiTabs({ Root, TabBar, Tab, TabActive, Content, tabsJson, defaultTab }: {
  Root: Slot; TabBar: Slot; Tab: Slot; TabActive: Slot; Content: Slot;
  tabsJson: string; defaultTab: string;
}) {
  let tabs: Array<{ id: string; label: string }> = [];
  try { tabs = JSON.parse(tabsJson); } catch { /* ignore */ }

  const tabElements = tabs.map(tab => {
    const isActive = tab.id === defaultTab;
    const slot = isActive ? TabActive : Tab;
    return React.createElement(slot.type, { ...slot.props, key: tab.id }, tab.label);
  });

  return S(
    Root,
    S(TabBar, ...tabElements),
    S(
      Content,
      React.createElement("span", { style: { fontSize: 12, color: "#5b5b66" } },
        `Conteúdo da tab: ${defaultTab}`,
      ),
    ),
  );
}

export function OrquiSearch({ Root, Icon, Input, placeholder }: {
  Root: Slot; Icon: Slot; Input: Slot;
  placeholder: string;
}) {
  return S(
    Root,
    S(Icon, "🔍"),
    React.createElement(
      Input.type,
      { ...Input.props, as: "input", readOnly: true, placeholder },
    ),
  );
}

export function OrquiSelect({ Root, placeholder, optionsJson }: {
  Root: Slot; placeholder: string; optionsJson: string;
}) {
  let options: Array<{ value: string; label: string }> = [];
  try { options = JSON.parse(optionsJson); } catch { /* ignore */ }

  return React.createElement(
    Root.type,
    { ...Root.props },
    React.createElement("select", {
      disabled: true,
      style: {
        background: "transparent", border: "none", color: "inherit",
        fontSize: "inherit", width: "100%", outline: "none",
      },
    },
      React.createElement("option", { value: "" }, placeholder),
      ...options.map(opt =>
        React.createElement("option", { key: opt.value, value: opt.value }, opt.label),
      ),
    ),
  );
}

export function OrquiSlot({ Root, name }: { Root: Slot; name: string }) {
  return S(Root, React.createElement("span", null, `⧉ Slot: ${name}`));
}

// ============================================================================
// Component Map — keyed by definition ID for Easyblocks
// ============================================================================

export const ORQUI_COMPONENTS: Record<string, ComponentType<any>> = {
  OrquiStack,
  OrquiRow,
  OrquiGrid,
  OrquiContainer,
  OrquiHeading,
  OrquiText,
  OrquiButton,
  OrquiBadge,
  OrquiIcon,
  OrquiImage,
  OrquiDivider,
  OrquiSpacer,
  OrquiStatCard,
  OrquiCard,
  OrquiTable,
  OrquiList,
  OrquiKeyValue,
  OrquiTabs,
  OrquiSearch,
  OrquiSelect,
  OrquiSlot,
};
