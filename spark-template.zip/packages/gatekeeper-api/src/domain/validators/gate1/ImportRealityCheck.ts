import type { ValidatorDefinition, ValidationContext, ValidatorOutput } from '../../../types/index.js'
import { readFileSync, existsSync } from 'fs'
import { resolve, dirname, join } from 'path'

export const ImportRealityCheckValidator: ValidatorDefinition = {
  code: 'IMPORT_REALITY_CHECK',
  name: 'Import Reality Check',
  description: 'Verifica se imports do teste existem',
  gate: 1,
  order: 8,
  isHardBlock: true,
  
  async execute(ctx: ValidationContext): Promise<ValidatorOutput> {
    if (!ctx.testFilePath) {
      return {
        passed: false,
        status: 'FAILED',
        message: 'No test file path provided',
      }
    }

    try {
      const sourceFile = ctx.services.ast.parseFile(ctx.testFilePath)
      const imports = ctx.services.ast.getImports(sourceFile)
      
      const invalidImports: Array<{path: string, reason: string}> = []
      const testFileDir = dirname(resolve(ctx.projectPath, ctx.testFilePath))
      
      for (const importPath of imports) {
        if (importPath.startsWith('.') || importPath.startsWith('/')) {
          let resolvedPath = importPath
          if (importPath.startsWith('.')) {
            resolvedPath = resolve(testFileDir, importPath)
          } else {
            resolvedPath = resolve(ctx.projectPath, importPath.slice(1))
          }
          
          const possibleExtensions = ['', '.ts', '.tsx', '.js', '.jsx', '/index.ts', '/index.tsx', '/index.js', '/index.jsx']
          let exists = false
          
          for (const ext of possibleExtensions) {
            if (existsSync(resolvedPath + ext)) {
              exists = true
              break
            }
          }
          
          if (!exists) {
            invalidImports.push({
              path: importPath,
              reason: 'File does not exist',
            })
          }
        } else {
          const packageJsonPath = resolve(ctx.projectPath, 'package.json')
          if (existsSync(packageJsonPath)) {
            try {
              const packageJson = JSON.parse(readFileSync(packageJsonPath, 'utf-8'))
              const allDeps = {
                ...(packageJson.dependencies || {}),
                ...(packageJson.devDependencies || {}),
              }
              
              const packageName = importPath.startsWith('@') 
                ? importPath.split('/').slice(0, 2).join('/')
                : importPath.split('/')[0]
              
              if (!allDeps[packageName]) {
                invalidImports.push({
                  path: importPath,
                  reason: `Package "${packageName}" not found in dependencies`,
                })
              }
            } catch (error) {
              ctx.services.log.warn('Failed to parse package.json', { error })
            }
          }
        }
      }

      if (invalidImports.length > 0) {
        return {
          passed: false,
          status: 'FAILED',
          message: `Found ${invalidImports.length} invalid import(s)`,
          evidence: `Invalid imports:\n${invalidImports.map(i => `  - ${i.path}: ${i.reason}`).join('\n')}`,
          details: {
            invalidImports,
            totalImports: imports.length,
          },
        }
      }

      return {
        passed: true,
        status: 'PASSED',
        message: 'All imports are valid and exist',
        metrics: {
          totalImports: imports.length,
          validImports: imports.length,
        },
      }
    } catch (error) {
      return {
        passed: false,
        status: 'FAILED',
        message: `Failed to check imports: ${error instanceof Error ? error.message : String(error)}`,
      }
    }
  },
}
