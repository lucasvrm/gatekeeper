import { describe, it, expect } from 'vitest'

describe('Example', () => {
  it('should pass', () => {
    expect(true).toBe(true)
  })
})
